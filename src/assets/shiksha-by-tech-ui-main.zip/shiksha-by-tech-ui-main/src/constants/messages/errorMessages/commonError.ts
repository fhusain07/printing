export const commonError = {
  numberLimit: "Phone number cannot be more than 10 digits",
  emailFormat: "Email is not valid",
};
