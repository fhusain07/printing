
function Subject() {
  return <div>Subject</div>;
}

export default Subject;
