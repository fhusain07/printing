
function AboutUsUI() {
  return <div>about us</div>;
}

export default AboutUsUI;
