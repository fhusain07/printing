import AboutUsUI from "./AboutUsUI";

function AboutUs() {
  return <AboutUsUI />;
}

export default AboutUs;
