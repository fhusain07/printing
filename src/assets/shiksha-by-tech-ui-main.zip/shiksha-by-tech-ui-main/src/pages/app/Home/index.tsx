import HomeUI from "./HomeUI";

function Home() {
  return <HomeUI />;
}

export default Home;
