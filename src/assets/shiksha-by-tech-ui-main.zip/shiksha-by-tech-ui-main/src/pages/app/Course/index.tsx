import CourseUI from "./CourseUI";

function Course() {
  return <CourseUI />;
}

export default Course;
