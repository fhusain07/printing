export enum EFilterCourseType {
  Rating = "rating",
  Level = "levels",
  Topics = "topics",
  Subcategory = "subcategory",
  Sort = "sort",
}
